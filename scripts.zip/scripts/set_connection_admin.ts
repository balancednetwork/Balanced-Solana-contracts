//imports
import * as anchor from "@coral-xyz/anchor";
import { Keypair, PublicKey } from "@solana/web3.js";

import { TransactionHelper, sleep } from "./utils";
import { TestContext as AssetManagerContext, AssetManagerPDA } from "./asset_manager/setup";
import { XcallPDA, ConnectionPDA } from "./utils/xcall_pda";
import { TestContext as xCallManagerContext, XcallManagerPDA } from "./xcall_manager/setup";
import { TestContext as BalancedDollarContext, BalancedDollarPDA } from "./balanced_dollar/setup";


import { AssetManager } from "../target/types/asset_manager";
import { XcallManager } from "../target/types/xcall_manager";
import { BalancedDollar } from "../target/types/balanced_dollar";
import { Xcall } from "../types/xcall";
import { CentralizedConnection } from "../types/centralized_connection";

const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);
const connection = provider.connection; //new Connection("https://solana-rpc.venture23.xyz", "confirmed");
let wallet = provider.wallet as anchor.Wallet;
let txnHelpers = new TransactionHelper(connection, wallet.payer);

import connectionIdlJson from "../target/idl/centralized_connection.json";
const connectionProgram: anchor.Program<CentralizedConnection> =
  new anchor.Program(connectionIdlJson as anchor.Idl, provider) as unknown as anchor.Program<CentralizedConnection> ;
  import xcallIdlJson from "../target/idl/xcall.json";
const xcall_program: anchor.Program<Xcall> = new anchor.Program(xcallIdlJson as anchor.Idl, provider) as unknown as anchor.Program<Xcall> ;
import xcallManagerIdlJson from "../target/idl/xcall_manager.json";
const xcall_manager_program: anchor.Program<XcallManager> =
new anchor.Program(xcallManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<XcallManager> ;
  import assetManagerIdlJson from "../target/idl/asset_manager.json";
const asset_manager_program: anchor.Program<AssetManager> =
new anchor.Program(assetManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<AssetManager> ;
import balancedDollarIdlJson from "../target/idl/balanced_dollar.json";
const balanced_dollar_program: anchor.Program<BalancedDollar> =
new anchor.Program(balancedDollarIdlJson as anchor.Idl, provider) as unknown as anchor.Program<BalancedDollar> ;
import * as rlp from 'rlp';

import { TestContext as XcallContext } from "./xcall/setup";
import { TestContext as ConnectionContext } from "./centralized_connection/setup";

import { SYSTEM_PROGRAM_ID } from "@coral-xyz/anchor/dist/cjs/native/system";
import assert from "assert";
import { Account, createMint, getOrCreateAssociatedTokenAccount, mintTo, TOKEN_PROGRAM_ID } from "@solana/spl-token";


let connectionCtx = new ConnectionContext(
    connection,
    txnHelpers,
    wallet.payer
);
let xcallCtx = new XcallContext(connection, txnHelpers, wallet.payer);
let xcallManagerCtx =  new xCallManagerContext(
    connection, txnHelpers, wallet.payer
);
let assetManagerContext =  new AssetManagerContext(
    connection, txnHelpers, wallet.payer
);
let balancedDollarContext =  new BalancedDollarContext(
    connection, txnHelpers, wallet.payer
);


async function connectionAdmin(admin: PublicKey) {
    console.log("setting network fee");
    await connectionProgram.methods
      .setAdmin(admin)
      .accountsStrict({
        admin: wallet.payer.publicKey,
        config: ConnectionPDA.config().pda,
      })
      .signers([wallet.payer])
      .rpc();
    console.log("network fee successfully set");
}


async function main() {
    await connectionAdmin(new PublicKey("7GoW5ACKgsKcjWKnfPXeGyZHMSNBJkqHFwjt5ex2i73z"));
}

main().catch(err => console.error(err));


