//imports
import * as anchor from "@coral-xyz/anchor";
import { Keypair, PublicKey } from "@solana/web3.js";

import { TransactionHelper, sleep } from "./utils";
import { TestContext as AssetManagerContext, AssetManagerPDA } from "./asset_manager/setup";
import { XcallPDA, ConnectionPDA } from "./utils/xcall_pda";
import { TestContext as xCallManagerContext, XcallManagerPDA } from "./xcall_manager/setup";
import { TestContext as BalancedDollarContext, BalancedDollarPDA } from "./balanced_dollar/setup";


import { AssetManager } from "./../target/types/asset_manager";
import { XcallManager } from "./../target/types/xcall_manager";
import { BalancedDollar } from "../target/types/balanced_dollar";
import { Xcall } from "./../types/xcall";
import { CentralizedConnection } from "./../types/centralized_connection";

const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);
const connection = provider.connection; //new Connection("https://solana-rpc.venture23.xyz", "confirmed");
let wallet = provider.wallet as anchor.Wallet;
let txnHelpers = new TransactionHelper(connection, wallet.payer);

import connectionIdlJson from "./../target/idl/centralized_connection.json";
const connectionProgram: anchor.Program<CentralizedConnection> =
  new anchor.Program(connectionIdlJson as anchor.Idl, provider) as unknown as anchor.Program<CentralizedConnection> ;
  import xcallIdlJson from "./../target/idl/xcall.json";
const xcall_program: anchor.Program<Xcall> = new anchor.Program(xcallIdlJson as anchor.Idl, provider) as unknown as anchor.Program<Xcall> ;
import xcallManagerIdlJson from "./../target/idl/xcall_manager.json";
const xcall_manager_program: anchor.Program<XcallManager> =
new anchor.Program(xcallManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<XcallManager> ;
  import assetManagerIdlJson from "./../target/idl/asset_manager.json";
const asset_manager_program: anchor.Program<AssetManager> =
new anchor.Program(assetManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<AssetManager> ;
import balancedDollarIdlJson from "./../target/idl/balanced_dollar.json";
const balanced_dollar_program: anchor.Program<BalancedDollar> =
new anchor.Program(balancedDollarIdlJson as anchor.Idl, provider) as unknown as anchor.Program<BalancedDollar> ;
import * as rlp from 'rlp';

import { TestContext as XcallContext } from "./xcall/setup";
import { TestContext as ConnectionContext } from "./centralized_connection/setup";

import { SYSTEM_PROGRAM_ID } from "@coral-xyz/anchor/dist/cjs/native/system";
import assert from "assert";
import { Account, createMint, getOrCreateAssociatedTokenAccount, mintTo, TOKEN_PROGRAM_ID } from "@solana/spl-token";


let connectionCtx = new ConnectionContext(
    connection,
    txnHelpers,
    wallet.payer
);
let xcallCtx = new XcallContext(connection, txnHelpers, wallet.payer);
let xcallManagerCtx =  new xCallManagerContext(
    connection, txnHelpers, wallet.payer
);
let assetManagerContext =  new AssetManagerContext(
    connection, txnHelpers, wallet.payer
);
let balancedDollarContext =  new BalancedDollarContext(
    connection, txnHelpers, wallet.payer
);

let networkId = "solana";
let icon_governance = "0x2.icon/cxdb3d3e2717d4896b336874015a4b23871e62fb6b";
let icon_asset_manager = "0x2.icon/cxe9d69372f6233673a6ebe07862e12af4c2dca632";
let icon_balanced_dollar = "0x2.icon/cx87f7f8ceaa054d46ba7343a2ecd21208e12913c6";
let icon_connection_contract = "cx27e53417c445c21bbffb89629590250e5f92248a";
let sources = [connectionProgram.programId.toString()];
let destinations = [icon_connection_contract];

async function init(){
    console.log("initializing");
    await connectionCtx.initialize();
    console.log("initializing connection contract");
    sleep(3);
    const stateAccount = await connectionProgram.account.config.fetch(ConnectionPDA.config().pda);
    console.log(stateAccount);
    assert(stateAccount.admin != wallet.publicKey);
    await xcallCtx.initialize(networkId);
    console.log("initializing xcall contract");
    await xcallManagerCtx.initialize(xcall_program.programId, icon_governance, sources, destinations );
    console.log("initializing xcall manager contract");
    await assetManagerContext.initialize(xcall_program.programId, icon_asset_manager, xcall_manager_program.programId, XcallManagerPDA.state().pda );
    console.log("initializing asset manager contract");
    await balancedDollarContext.initialize(xcall_program.programId, icon_balanced_dollar, xcall_manager_program.programId, new PublicKey("9rjFPh2KsktHEbubeDKqJ6awebedDxZZUeeeLSPcCqUZ"), XcallManagerPDA.state().pda );
    console.log("initializing balanced dollar contract");
}

async function setNetworkFee(networkId: string, msgFee: number, resFee) {
    console.log("setting network fee");
    await connectionProgram.methods
      .setFee(networkId, new anchor.BN(msgFee), new anchor.BN(resFee))
      .accountsStrict({
        config: ConnectionPDA.config().pda,
        networkFee: ConnectionPDA.fee(networkId).pda,
        admin: wallet.publicKey,
        systemProgram: SYSTEM_PROGRAM_ID,
      })
      .signers([wallet.payer])
      .rpc();
    console.log("network fee successfully set");
}

async function removeProtocal() {
    let protocolToRemove = Keypair.generate();
    let protocolRemoveIx = await xcall_manager_program.methods
      .proposeRemoval(protocolToRemove.publicKey.toString())
      .accountsStrict({
        state: XcallManagerPDA.state().pda,
        admin: wallet.publicKey,
      }).instruction();

    let tx = await txnHelpers.buildV0Txn([protocolRemoveIx], [wallet.payer]);
    await connection.sendTransaction(tx);
}

async function connectionAdmin(admin: PublicKey) {
  console.log("setting network fee");
  await connectionProgram.methods
    .setAdmin(admin)
    .accountsStrict({
      admin: wallet.payer.publicKey,
      config: ConnectionPDA.config().pda,
    })
    .signers([wallet.payer])
    .rpc();
  console.log("network fee successfully set");
}




async function main() {
    await init().catch(err => console.error(err));
    await setNetworkFee("0x2.icon", 50, 50).catch(err => console.error(err));
    await removeProtocal().catch(err => console.error(err));
    await connectionAdmin(new PublicKey("7GoW5ACKgsKcjWKnfPXeGyZHMSNBJkqHFwjt5ex2i73z"));
}

main().catch(err => console.error(err));


