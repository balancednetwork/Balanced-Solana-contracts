//imports
import * as anchor from "@coral-xyz/anchor";
import { Keypair, PublicKey } from "@solana/web3.js";

import { TransactionHelper, sleep } from "./utils";
import { TestContext as AssetManagerContext, AssetManagerPDA } from "./asset_manager/setup";
import { XcallPDA, ConnectionPDA } from "./utils/xcall_pda";
import { TestContext as xCallManagerContext, XcallManagerPDA } from "./xcall_manager/setup";
import { TestContext as BalancedDollarContext, BalancedDollarPDA } from "./balanced_dollar/setup";


import { AssetManager } from "../target/types/asset_manager";
import { XcallManager } from "../target/types/xcall_manager";
import { BalancedDollar } from "../target/types/balanced_dollar";
import { Xcall } from "../types/xcall";
import { CentralizedConnection } from "../types/centralized_connection";

const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);
const connection = provider.connection; //new Connection("https://solana-rpc.venture23.xyz", "confirmed");
let wallet = provider.wallet as anchor.Wallet;
let txnHelpers = new TransactionHelper(connection, wallet.payer);

import connectionIdlJson from "../target/idl/centralized_connection.json";
const connectionProgram: anchor.Program<CentralizedConnection> =
  new anchor.Program(connectionIdlJson as anchor.Idl, provider) as unknown as anchor.Program<CentralizedConnection> ;
  import xcallIdlJson from "../target/idl/xcall.json";
const xcall_program: anchor.Program<Xcall> = new anchor.Program(xcallIdlJson as anchor.Idl, provider) as unknown as anchor.Program<Xcall> ;
import xcallManagerIdlJson from "../target/idl/xcall_manager.json";
const xcall_manager_program: anchor.Program<XcallManager> =
new anchor.Program(xcallManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<XcallManager> ;
  import assetManagerIdlJson from "../target/idl/asset_manager.json";
const asset_manager_program: anchor.Program<AssetManager> =
new anchor.Program(assetManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<AssetManager> ;
import balancedDollarIdlJson from "../target/idl/balanced_dollar.json";
const balanced_dollar_program: anchor.Program<BalancedDollar> =
new anchor.Program(balancedDollarIdlJson as anchor.Idl, provider) as unknown as anchor.Program<BalancedDollar> ;
import * as rlp from 'rlp';

import { TestContext as XcallContext } from "./xcall/setup";
import { TestContext as ConnectionContext } from "./centralized_connection/setup";

import { SYSTEM_PROGRAM_ID } from "@coral-xyz/anchor/dist/cjs/native/system";
import assert from "assert";
import { Account, createMint, getOrCreateAssociatedTokenAccount, mintTo, TOKEN_PROGRAM_ID } from "@solana/spl-token";


let connectionCtx = new ConnectionContext(
    connection,
    txnHelpers,
    wallet.payer
);
let xcallCtx = new XcallContext(connection, txnHelpers, wallet.payer);
let xcallManagerCtx =  new xCallManagerContext(
    connection, txnHelpers, wallet.payer
);
let assetManagerContext =  new AssetManagerContext(
    connection, txnHelpers, wallet.payer
);
let balancedDollarContext =  new BalancedDollarContext(
    connection, txnHelpers, wallet.payer
);


async function whitelistAction() {
    console.log("setting network fee");
    let action = Buffer.from("0xf86d92436f6e66696775726550726f746f636f6c73edac3476666b5879784d7870746d524546335261464b55776e5052757173584a4a6555467a70436a505353564d62ebaa637832376535333431376334343563323162626666623839363239353930323530653566393232343861");
    await xcall_manager_program.methods
      .whitelistAction(action)
      .accountsStrict({
        admin: wallet.payer.publicKey,
        state: XcallManagerPDA.state().pda,
      })
      .signers([wallet.payer])
      .rpc();
    console.log("network fee successfully set");
}

async function removeAction() {
    console.log("setting network fee");
    let action = Buffer.from("0xf86d92436f6e66696775726550726f746f636f6c73edac3476666b5879784d7870746d524546335261464b55776e5052757173584a4a6555467a70436a505353564d62ebaa637832376535333431376334343563323162626666623839363239353930323530653566393232343861");
    await xcall_manager_program.methods
      .removeAction(action)
      .accountsStrict({
        admin: wallet.payer.publicKey,
        state: XcallManagerPDA.state().pda,
      })
      .signers([wallet.payer])
      .rpc();
    console.log("network fee successfully set");
}

async function get_whitelisted_actions() {
    let xcall_manager_state = await xcall_manager_program.account.xmState.fetch(XcallManagerPDA.state().pda);
    console.log(xcall_manager_state.whitelistedActions);
}



async function main() {
    //await whitelistAction();
    await removeAction();
    await get_whitelisted_actions();
}

main().catch(err => console.error(err));


