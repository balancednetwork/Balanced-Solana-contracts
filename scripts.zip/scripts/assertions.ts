//imports
import * as anchor from "@coral-xyz/anchor";
import { Keypair, PublicKey } from "@solana/web3.js";


import { TransactionHelper, sleep } from "./utils";
import { TestContext as AssetManagerContext, AssetManagerPDA } from "./asset_manager/setup";
import { XcallPDA, ConnectionPDA } from "./utils/xcall_pda";
import { TestContext as xCallManagerContext, XcallManagerPDA } from "./xcall_manager/setup";
import { TestContext as BalancedDollarContext, BalancedDollarPDA } from "./balanced_dollar/setup";


import { AssetManager } from "../target/types/asset_manager";
import { XcallManager } from "../target/types/xcall_manager";
import { Xcall } from "../types/xcall";
import { CentralizedConnection } from "../types/centralized_connection";

const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);
const connection = provider.connection; //new Connection("https://solana-rpc.venture23.xyz", "confirmed");
let wallet = provider.wallet as anchor.Wallet;
let txnHelpers = new TransactionHelper(connection, wallet.payer);

import connectionIdlJson from "./../target/idl/centralized_connection.json";
const connectionProgram: anchor.Program<CentralizedConnection> =
  new anchor.Program(connectionIdlJson as anchor.Idl, provider) as unknown as anchor.Program<CentralizedConnection> ;
  import xcallIdlJson from "./../target/idl/xcall.json";
const xcall_program: anchor.Program<Xcall> = new anchor.Program(xcallIdlJson as anchor.Idl, provider) as unknown as anchor.Program<Xcall> ;
import xcallManagerIdlJson from "./../target/idl/xcall_manager.json";
const xcall_manager_program: anchor.Program<XcallManager> =
new anchor.Program(xcallManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<XcallManager> ;
  import assetManagerIdlJson from "./../target/idl/asset_manager.json";
const asset_manager_program: anchor.Program<AssetManager> =
new anchor.Program(assetManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<AssetManager> ;
import balancedDollarIdlJson from "./../target/idl/balanced_dollar.json";
const balanced_dollar_program: anchor.Program<BalancedDollar> =
new anchor.Program(balancedDollarIdlJson as anchor.Idl, provider) as unknown as anchor.Program<BalancedDollar> ;
import * as rlp from 'rlp';

import { TestContext as XcallContext } from "./xcall/setup";
import { TestContext as ConnectionContext } from "./centralized_connection/setup";
import { BalancedDollar } from "../target/types/balanced_dollar";
import { assert } from "console";

let connectionCtx = new ConnectionContext(
    connection,
    txnHelpers,
    wallet.payer
);
let xcallCtx = new XcallContext(connection, txnHelpers, wallet.payer);
let xcallManagerCtx =  new xCallManagerContext(
    connection, txnHelpers, wallet.payer
);
let assetManagerContext =  new AssetManagerContext(
    connection, txnHelpers, wallet.payer
);
let balancedDollarContext =  new BalancedDollarContext(
    connection, txnHelpers, wallet.payer
);

let networkId = "solana";
let icon_governance = "0x2.icon/cxdb3d3e2717d4896b336874015a4b23871e62fb6b";
let icon_asset_manager = "0x2.icon/cxe9d69372f6233673a6ebe07862e12af4c2dca632";
let icon_balanced_dollar = "0x2.icon/cx87f7f8ceaa054d46ba7343a2ecd21208e12913c6";
let icon_connection_contract = "cx07300971594d7160a9ec62e4ec68d8fa10b9d9dc";
let sources = [connectionProgram.programId.toString()];
let destinations = [icon_connection_contract];

async function assert_connection_states(){
  const stateAccount = await connectionProgram.account.config.fetch(ConnectionPDA.config().pda);
  console.log(stateAccount);
  assert(stateAccount.admin != null);
  console.log("connection asserted");
}

async function assert_xcall_manager_states(){
  const stateAccount = await xcall_manager_program.account.xmState.fetch(XcallManagerPDA.state().pda);
  let stateSources = stateAccount.sources;
  let stateDestinations = stateAccount.destinations;
  console.log("destinations: ", stateDestinations[0]);
  console.log("sources: ", stateSources[0]);
  console.log("set destinations: ", destinations[0]);
  console.log("set sources: ", sources[0]);
  assert(sources[0] == stateSources[0]);
  assert(destinations[0] == stateDestinations[0]);
  console.log("xcall_manager_asserted");
}

async function assert_am_states(){
  const stateAccount = await asset_manager_program.account.state.fetch(AssetManagerPDA.state().pda);
  let icon_asset_manager_state = stateAccount.iconAssetManager;

  assert(icon_asset_manager == icon_asset_manager_state);
  console.log("asset manager asserted");
}

async function assert_bnusd_states(){
  const stateAccount = await balanced_dollar_program.account.state.fetch(BalancedDollarPDA.state().pda);
  let icon_bnusd_state = stateAccount.iconBnUsd;

  assert(icon_bnusd_state == icon_balanced_dollar);
  console.log("balanced dollar asserted");
}

async function main() {
  await assert_connection_states().catch(err => console.error(err));
  await assert_xcall_manager_states().catch(err => console.error(err));
  await assert_am_states().catch(err => console.error(err));
  await assert_bnusd_states().catch(err => console.error(err));
}

main().catch(err => console.error(err));