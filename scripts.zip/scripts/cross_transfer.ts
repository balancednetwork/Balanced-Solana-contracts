//imports
import fs from 'fs';
import * as anchor from "@coral-xyz/anchor";
import { Keypair, PublicKey } from "@solana/web3.js";

import { TransactionHelper, sleep } from "./utils";
import { TestContext as AssetManagerContext, AssetManagerPDA } from "./asset_manager/setup";
import { XcallPDA, ConnectionPDA } from "./utils/xcall_pda";
import { TestContext as xCallManagerContext, XcallManagerPDA } from "./xcall_manager/setup";
import { TestContext as BalancedDollarContext, BalancedDollarPDA } from "./balanced_dollar/setup";


import { AssetManager } from "../target/types/asset_manager";
import { XcallManager } from "../target/types/xcall_manager";
import { Xcall } from "../types/xcall";
import { CentralizedConnection } from "../types/centralized_connection";
const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);
const connection = provider.connection; //new Connection("https://solana-rpc.venture23.xyz", "confirmed");
let wallet = provider.wallet as anchor.Wallet;
let txnHelpers = new TransactionHelper(connection, wallet.payer);

import connectionIdlJson from "./../target/idl/centralized_connection.json";
const connectionProgram: anchor.Program<CentralizedConnection> =
  new anchor.Program(connectionIdlJson as anchor.Idl, provider) as unknown as anchor.Program<CentralizedConnection> ;
  import xcallIdlJson from "./../target/idl/xcall.json";
const xcall_program: anchor.Program<Xcall> = new anchor.Program(xcallIdlJson as anchor.Idl, provider) as unknown as anchor.Program<Xcall> ;
import xcallManagerIdlJson from "./../target/idl/xcall_manager.json";
const xcall_manager_program: anchor.Program<XcallManager> =
new anchor.Program(xcallManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<XcallManager> ;
  import assetManagerIdlJson from "./../target/idl/asset_manager.json";
const asset_manager_program: anchor.Program<AssetManager> =
new anchor.Program(assetManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<AssetManager> ;
import balancedDollarIdlJson from "./../target/idl/balanced_dollar.json";
const balanced_dollar_program: anchor.Program<BalancedDollar> =
new anchor.Program(balancedDollarIdlJson as anchor.Idl, provider) as unknown as anchor.Program<BalancedDollar> ;
import * as rlp from 'rlp';

import { TestContext as XcallContext } from "./xcall/setup";
import { TestContext as ConnectionContext } from "./centralized_connection/setup";
import { BalancedDollar } from "../target/types/balanced_dollar";
import { assert, error } from "console";
import { Account, createMint, getOrCreateAssociatedTokenAccount, TOKEN_PROGRAM_ID } from "@solana/spl-token";
import { SYSTEM_PROGRAM_ID } from "@coral-xyz/anchor/dist/cjs/native/system";



let connectionCtx = new ConnectionContext(
    connection,
    txnHelpers,
    wallet.payer
);
let xcallCtx = new XcallContext(connection, txnHelpers, wallet.payer);
let xcallManagerCtx =  new xCallManagerContext(
    connection, txnHelpers, wallet.payer
);
let assetManagerContext =  new AssetManagerContext(
    connection, txnHelpers, wallet.payer
);
let balancedDollarContext =  new BalancedDollarContext(
    connection, txnHelpers, wallet.payer
);

let networkId = "solana";
let icon_governance = "0x2.icon/cxdb3d3e2717d4896b336874015a4b23871e62fb6b";
let icon_asset_manager = "0x2.icon/cxe9d69372f6233673a6ebe07862e12af4c2dca632";
let icon_balanced_dollar = "0x2.icon/cx87f7f8ceaa054d46ba7343a2ecd21208e12913c6";
let icon_connection_contract = "cx07300971594d7160a9ec62e4ec68d8fa10b9d9dc";
let sources = [connectionProgram.programId.toString()];
let destinations = [icon_connection_contract];

let mint: PublicKey;
let program_authority = BalancedDollarPDA.program_authority();
///Users/sagarsapkota/docs/ibriz/solanawallet/devnet_wallet.json
const walletPath = "/Users/sagarsapkota/docs/ibriz/solanawallet/devnet_wallet.json"; // Update this to the actual path
const secretKey = JSON.parse(fs.readFileSync(walletPath, 'utf8'));
const withdrawerKeyPair = Keypair.fromSecretKey(new Uint8Array(secretKey));

//let withdrawerKeyPair = Keypair.generate();
let withdrawerTokenAccount: Account;

async function cross_transfer() {
    mint = new PublicKey("9rjFPh2KsktHEbubeDKqJ6awebedDxZZUeeeLSPcCqUZ");
    withdrawerTokenAccount = await getOrCreateAssociatedTokenAccount(
      provider.connection,
      wallet.payer,
      mint,
      withdrawerKeyPair.publicKey,
      true
    );

    let { pda } = XcallPDA.config();
    let xcall_config = await xcall_program.account.config.fetch(pda);
    console.log("sequence no: ", xcall_config.sequenceNo);
    //const stateAccount = await balanced_dollar_program.account.state.fetch(BalancedDollarPDA.state().pda);
    //let iconBnUsd = stateAccount.iconBnUsd;
    //let sender = Keypair.generate();
    //const data = ["xCrossTransfer", sender.publicKey.toString(), withdrawerKeyPair.publicKey.toString(), 20000000000,  Buffer.alloc(0)];
    //const rlpEncodedData = rlp.encode(data);
  
    //let protocols = xcall_manager_program.account.xmState.fetch(BalancedDollarPDA.xcall_manager_state().pda);
    // await balanced_dollar_program.methods
    // .handleCallMessage(iconBnUsd, Buffer.from(rlpEncodedData), (await protocols).sources )
    // .accountsStrict({
    //   state: BalancedDollarPDA.state().pda,
    //   to: withdrawerTokenAccount.address,
    //   mint: mint,
    //   mintAuthority: program_authority.pda,
    //   xcallManager: xcall_manager_program.programId,
    //   tokenProgram: TOKEN_PROGRAM_ID,
    //   xcall: xcall_program.programId,
    //   xcallManagerState: BalancedDollarPDA.xcall_manager_state().pda
    // }).signers([wallet.payer]).rpc();
    // await  sleep(3);
    console.log(withdrawerTokenAccount.address);
    const tokenAccountInfo = await connection.getTokenAccountBalance(withdrawerTokenAccount.address);

    let balance = tokenAccountInfo.value.amount;
    console.log("balanced of withdrawer: {}", balance);
    //assert(balance == "20000000000");
    await txnHelpers.airdrop(withdrawerKeyPair.publicKey, 5000000000);
    await  sleep(3);
    let bytes = Buffer.alloc(0);
    let crossTransferTx = await balanced_dollar_program.methods
      .crossTransfer("0x2.icon/hxd911279d689705ecdcffc8b884915f89968232568", new anchor.BN(1000000000), bytes)
      .accountsStrict({
        from: withdrawerTokenAccount.address,
        fromAuthority: withdrawerKeyPair.publicKey,
        state: BalancedDollarPDA.state().pda,
        mint: mint,
        xcallManagerState: BalancedDollarPDA.xcall_manager_state().pda,
        xcallConfig: XcallPDA.config().pda,
        xcall: xcall_program.programId,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SYSTEM_PROGRAM_ID,
      }).remainingAccounts([
        {
          pubkey: XcallPDA.config().pda,
          isSigner: false,
          isWritable: true,
        },
        {
          pubkey: XcallPDA.rollback(xcall_config.sequenceNo.toNumber() + 1).pda,
          isSigner: false,
          isWritable: true,
        },
        {
          pubkey: new PublicKey("Sysvar1nstructions1111111111111111111111111"),
          isSigner: false,
          isWritable: false,
        },
        {
          pubkey: xcall_config.feeHandler,
          isSigner: false,
          isWritable: true,
        },
        //connection params
        {
          pubkey: connectionProgram.programId,
          isSigner: false,
          isWritable: true,
        },
        {
          pubkey: ConnectionPDA.config().pda,
          isSigner: false,
          isWritable: true,
        },
        {
          pubkey: ConnectionPDA.fee("0x2.icon").pda,
          isSigner: false,
          isWritable: true,
        }
      ]).instruction();
      let tx = await txnHelpers.buildV0Txn([crossTransferTx], [withdrawerKeyPair]);
      let txHash = await connection.sendTransaction(tx);
      await txnHelpers.logParsedTx(txHash);

    const updatedTokenAccountInfo = await connection.getTokenAccountBalance(withdrawerTokenAccount.address);
    let updatedBalance = updatedTokenAccountInfo.value.amount;
    console.log("balanced of withdrawer: {}", updatedBalance);
}

async function main() {
    
    await cross_transfer();
}

main().catch(err=>console.log(err));