//imports
import * as anchor from "@coral-xyz/anchor";
import { Keypair, PublicKey } from "@solana/web3.js";

import { TransactionHelper, sleep } from "./utils";
import { TestContext as AssetManagerContext, AssetManagerPDA } from "./asset_manager/setup";
import { XcallPDA, ConnectionPDA } from "./utils/xcall_pda";
import { TestContext as xCallManagerContext, XcallManagerPDA } from "./xcall_manager/setup";
import { TestContext as BalancedDollarContext, BalancedDollarPDA } from "./balanced_dollar/setup";


import { AssetManager } from "./../target/types/asset_manager";
import { XcallManager } from "./../target/types/xcall_manager";
import { BalancedDollar } from "../target/types/balanced_dollar";
import { Xcall } from "./../types/xcall";
import { CentralizedConnection } from "./../types/centralized_connection";

const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);
const connection = provider.connection; //new Connection("https://solana-rpc.venture23.xyz", "confirmed");
let wallet = provider.wallet as anchor.Wallet;
let txnHelpers = new TransactionHelper(connection, wallet.payer);

import connectionIdlJson from "./../target/idl/centralized_connection.json";
const connectionProgram: anchor.Program<CentralizedConnection> =
  new anchor.Program(connectionIdlJson as anchor.Idl, provider) as unknown as anchor.Program<CentralizedConnection> ;
  import xcallIdlJson from "./../target/idl/xcall.json";
const xcall_program: anchor.Program<Xcall> = new anchor.Program(xcallIdlJson as anchor.Idl, provider) as unknown as anchor.Program<Xcall> ;
import xcallManagerIdlJson from "./../target/idl/xcall_manager.json";
const xcall_manager_program: anchor.Program<XcallManager> =
new anchor.Program(xcallManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<XcallManager> ;
  import assetManagerIdlJson from "./../target/idl/asset_manager.json";
const asset_manager_program: anchor.Program<AssetManager> =
new anchor.Program(assetManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<AssetManager> ;
import balancedDollarIdlJson from "./../target/idl/balanced_dollar.json";
const balanced_dollar_program: anchor.Program<BalancedDollar> =
new anchor.Program(balancedDollarIdlJson as anchor.Idl, provider) as unknown as anchor.Program<BalancedDollar> ;
import * as rlp from 'rlp';

import { TestContext as XcallContext } from "./xcall/setup";
import { TestContext as ConnectionContext } from "./centralized_connection/setup";

import { SYSTEM_PROGRAM_ID } from "@coral-xyz/anchor/dist/cjs/native/system";
import assert from "assert";
import { Account, ASSOCIATED_TOKEN_PROGRAM_ID, createMint, getAccount, getAssociatedTokenAddress, getOrCreateAssociatedTokenAccount, mintTo, TOKEN_PROGRAM_ID } from "@solana/spl-token";


let connectionCtx = new ConnectionContext(
    connection,
    txnHelpers,
    wallet.payer
);
let xcallCtx = new XcallContext(connection, txnHelpers, wallet.payer);
let xcallManagerCtx =  new xCallManagerContext(
    connection, txnHelpers, wallet.payer
);
let assetManagerContext =  new AssetManagerContext(
    connection, txnHelpers, wallet.payer
);
let balancedDollarContext =  new BalancedDollarContext(
    connection, txnHelpers, wallet.payer
);

let networkId = "solana";
let icon_governance = "0x2.icon/cxdb3d3e2717d4896b336874015a4b23871e62fb6b";
let icon_asset_manager = "icon/ijijscidsoj";
let icon_balanced_dollar = "0x2.icon/cx87f7f8ceaa054d46ba7343a2ecd21208e12913c6";
let icon_connection_contract = "0x2.icon/cx07300971594d7160a9ec62e4ec68d8fa10b9d9dc";


async function init(){
    // console.log("vault");
    // const valult_account = await PublicKey.findProgramAddress(
    //     [
    //         AssetManagerPDA.vault(new PublicKey("CH4BeCJzn4DpcLxB1rYjaNX7qZSETRRC518euX4wGyDS")).pda.toBuffer(),
    //         TOKEN_PROGRAM_ID.toBuffer(),
    //         new PublicKey("CH4BeCJzn4DpcLxB1rYjaNX7qZSETRRC518euX4wGyDS").toBuffer(),
    //     ],
    //     ASSOCIATED_TOKEN_PROGRAM_ID
    // );

    // const vault_spl_token_balance = await getAccount(connection, valult_account[0]);

    // console.log(`Valult Balance: ${vault_spl_token_balance.amount}`);

    const balanced_token = await PublicKey.findProgramAddress(
        [
            new PublicKey("4f6jczLVJVn38LzEUBz5p76NpdQwiJPBbGj9jPC3Sw74").toBuffer(),
            TOKEN_PROGRAM_ID.toBuffer(),
            new PublicKey("9rjFPh2KsktHEbubeDKqJ6awebedDxZZUeeeLSPcCqUZ").toBuffer(),
        ],
        ASSOCIATED_TOKEN_PROGRAM_ID
    );

    const BalancedTokenAccount = await getAccount(connection, balanced_token[0]);

    console.log(`user bnusd Balance: ${BalancedTokenAccount.amount}`);

    const user_token_account = await PublicKey.findProgramAddress(
        [
            new PublicKey("4f6jczLVJVn38LzEUBz5p76NpdQwiJPBbGj9jPC3Sw74").toBuffer(),
            TOKEN_PROGRAM_ID.toBuffer(),
            new PublicKey("CH4BeCJzn4DpcLxB1rYjaNX7qZSETRRC518euX4wGyDS").toBuffer(),
        ],
        ASSOCIATED_TOKEN_PROGRAM_ID
    );

    const SplTokenAccount = await getAccount(connection, user_token_account[0]);

    console.log(`user spl token Balance: ${SplTokenAccount.amount}`);

}




async function main() {
    await init().catch(err => console.error(err));
}

main().catch(err => console.error(err));