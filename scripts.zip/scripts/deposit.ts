//imports
import fs from 'fs';
import * as anchor from "@coral-xyz/anchor";
import { Keypair, PublicKey, ComputeBudgetProgram } from "@solana/web3.js";

import { TransactionHelper, sleep } from "./utils";
import { TestContext as AssetManagerContext, AssetManagerPDA } from "./asset_manager/setup";
import { XcallPDA, ConnectionPDA } from "./utils/xcall_pda";
import { TestContext as xCallManagerContext, XcallManagerPDA } from "./xcall_manager/setup";
import { TestContext as BalancedDollarContext, BalancedDollarPDA } from "./balanced_dollar/setup";


import { AssetManager } from "../target/types/asset_manager";
import { XcallManager } from "../target/types/xcall_manager";
import { Xcall } from "../types/xcall";
import { CentralizedConnection } from "../types/centralized_connection";
const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);
const connection = provider.connection; //new Connection("https://solana-rpc.venture23.xyz", "confirmed");
let wallet = provider.wallet as anchor.Wallet;
let txnHelpers = new TransactionHelper(connection, wallet.payer);

import connectionIdlJson from "./../target/idl/centralized_connection.json";
const connectionProgram: anchor.Program<CentralizedConnection> =
  new anchor.Program(connectionIdlJson as anchor.Idl, provider) as unknown as anchor.Program<CentralizedConnection> ;
  import xcallIdlJson from "./../target/idl/xcall.json";
const xcall_program: anchor.Program<Xcall> = new anchor.Program(xcallIdlJson as anchor.Idl, provider) as unknown as anchor.Program<Xcall> ;
import xcallManagerIdlJson from "./../target/idl/xcall_manager.json";
const xcall_manager_program: anchor.Program<XcallManager> =
new anchor.Program(xcallManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<XcallManager> ;
  import assetManagerIdlJson from "./../target/idl/asset_manager.json";
const asset_manager_program: anchor.Program<AssetManager> =
new anchor.Program(assetManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<AssetManager> ;
import balancedDollarIdlJson from "./../target/idl/balanced_dollar.json";
const balanced_dollar_program: anchor.Program<BalancedDollar> =
new anchor.Program(balancedDollarIdlJson as anchor.Idl, provider) as unknown as anchor.Program<BalancedDollar> ;
import * as rlp from 'rlp';

import { TestContext as XcallContext } from "./xcall/setup";
import { TestContext as ConnectionContext } from "./centralized_connection/setup";
import { BalancedDollar } from "../target/types/balanced_dollar";
import { assert, error } from "console";
import { Account, createMint, getOrCreateAssociatedTokenAccount, mintTo, TOKEN_PROGRAM_ID } from "@solana/spl-token";
import { BN } from "bn.js";
import { SYSTEM_PROGRAM_ID } from "@coral-xyz/anchor/dist/cjs/native/system";



let connectionCtx = new ConnectionContext(
    connection,
    txnHelpers,
    wallet.payer
);
let xcallCtx = new XcallContext(connection, txnHelpers, wallet.payer);
let xcallManagerCtx =  new xCallManagerContext(
    connection, txnHelpers, wallet.payer
);
let assetManagerContext =  new AssetManagerContext(
    connection, txnHelpers, wallet.payer
);
let balancedDollarContext =  new BalancedDollarContext(
    connection, txnHelpers, wallet.payer
);

let networkId = "solana";
let icon_governance = "0x2.icon/cxdb3d3e2717d4896b336874015a4b23871e62fb6b";
let icon_asset_manager = "0x2.icon/cxe9d69372f6233673a6ebe07862e12af4c2dca632";
let icon_balanced_dollar = "0x2.icon/cx87f7f8ceaa054d46ba7343a2ecd21208e12913c6";
let icon_connection_contract = "cx07300971594d7160a9ec62e4ec68d8fa10b9d9dc";
let sources = [connectionProgram.programId.toString()];
let destinations = [icon_connection_contract];
const walletPath = "/Users/sagarsapkota/docs/ibriz/solanawallet/devnet_wallet.json"; // Update this to the actual path
const secretKey = JSON.parse(fs.readFileSync(walletPath, 'utf8'));
const depositorKeyPair = Keypair.fromSecretKey(new Uint8Array(secretKey));

let mint: PublicKey;
let vaultTokenAccount: Account;
async function createMintAndValultTokenAccount() {
    mint = new PublicKey("CH4BeCJzn4DpcLxB1rYjaNX7qZSETRRC518euX4wGyDS");

    let vaultTokenAccountPda = AssetManagerPDA.vault(mint).pda;
    vaultTokenAccount = await getOrCreateAssociatedTokenAccount(
        provider.connection,
        wallet.payer,
        mint,
        vaultTokenAccountPda,
        true
    );
    console.log("vault token: ", vaultTokenAccount);
}

async function configureRateLimit() {
    let configureIx = await asset_manager_program.methods
      .configureRateLimit(mint, new BN(300), new BN(900))
      .accountsStrict({
        admin: wallet.publicKey,
        state: AssetManagerPDA.state().pda,
        tokenState: AssetManagerPDA.token_state(mint).pda,
        vaultTokenAccount: vaultTokenAccount.address,
        mint: mint,
        systemProgram: SYSTEM_PROGRAM_ID
      }).instruction();
    let tx = await txnHelpers.buildV0Txn([configureIx], [wallet.payer]);
    await connection.sendTransaction(tx);
    await  sleep(3);
}

async function deposit() {
    
    let { pda } = XcallPDA.config();
    let xcall_config = await xcall_program.account.config.fetch(pda);
    //let depositorKeyPair = Keypair.generate();
    console.log("depositor key: ", depositorKeyPair.publicKey);
    let depositorTokenAccount = await getOrCreateAssociatedTokenAccount(
      provider.connection,
      wallet.payer,
      mint,
      depositorKeyPair.publicKey,
      true
    );
    await  sleep(3);
    console.log("token account: ", depositorTokenAccount.address);
    await mintTo(
      provider.connection,
      wallet.payer,
      mint,
      depositorTokenAccount.address,
      wallet.payer,
      10000000000,
      [wallet.payer],
      null,
      TOKEN_PROGRAM_ID
    );
    await  sleep(3);

    //console.log("xcall program id is: ", xcall_program.programId)
    await txnHelpers.airdrop(depositorKeyPair.publicKey, 5000000000);
    await  sleep(3);
    let bytes = Buffer.alloc(0);
    const tokenAccountInfo = await connection.getTokenAccountBalance(vaultTokenAccount.address);
    let balance = tokenAccountInfo.value.amount;
    console.log("token balance of vault account before deposit: ", balance);
    let depositTokenIx = await asset_manager_program.methods
      .depositToken(new BN(1000000000), "0x2.icon/hxd911279d689705ecdcffc8b884915f8996823256", bytes)
      .accountsStrict({
        from: depositorTokenAccount.address,
        vaultNativeAccount: null,
        fromAuthority: depositorKeyPair.publicKey,
        vaultTokenAccount: vaultTokenAccount.address,
        state: AssetManagerPDA.state().pda,
        xcallManagerState: AssetManagerPDA.xcall_manager_state().pda,
        xcallConfig: XcallPDA.config().pda,
        xcall: xcall_program.programId,
        xcallManager: xcall_manager_program.programId,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SYSTEM_PROGRAM_ID,
      }).remainingAccounts([
        {
          pubkey: XcallPDA.config().pda,
          isSigner: false,
          isWritable: true,
        },
        {
          pubkey: XcallPDA.rollback(xcall_config.sequenceNo.toNumber()+1).pda,
          isSigner: false,
          isWritable: true,
        },
        {
          pubkey: new PublicKey("Sysvar1nstructions1111111111111111111111111"),
          isSigner: false,
          isWritable: false,
        },
        {
          pubkey: xcall_config.feeHandler,
          isSigner: false,
          isWritable: true,
        },
        //connection params
        {
          pubkey: connectionProgram.programId,
          isSigner: false,
          isWritable: true,
        },
        {
          pubkey: ConnectionPDA.config().pda,
          isSigner: false,
          isWritable: true,
        },
        {
          pubkey: ConnectionPDA.fee("0x2.icon").pda,
          isSigner: false,
          isWritable: true,
        }
      ]).instruction();
    const modifyComputeUnits = ComputeBudgetProgram.setComputeUnitLimit({ 
      units: 1000000 
    });
    
    const addPriorityFee = ComputeBudgetProgram.setComputeUnitPrice({ 
      microLamports: 0
    });
    let tx = await txnHelpers.buildV0Txn([modifyComputeUnits, addPriorityFee, depositTokenIx], [depositorKeyPair]);
    let txHash = await connection.sendTransaction(tx);
    txnHelpers.logParsedTx(txHash);
    sleep(3);
    const updatedTokenAccountInfo = await connection.getTokenAccountBalance(vaultTokenAccount.address);
    let updatedBalance = updatedTokenAccountInfo.value.amount;
    console.log("token balance of vault account after deposit: ", updatedBalance);

}

async function main() {
    await createMintAndValultTokenAccount().catch(err => console.error(err));
    await configureRateLimit().catch(err => console.error(err));
    await deposit();
}

main().catch(err => console.error(err));