//imports
import fs from 'fs';
import * as anchor from "@coral-xyz/anchor";
import { Keypair, PublicKey, ComputeBudgetProgram } from "@solana/web3.js";

import { TransactionHelper, sleep } from "./utils";
import { TestContext as AssetManagerContext, AssetManagerPDA } from "./asset_manager/setup";
import { XcallPDA, ConnectionPDA } from "./utils/xcall_pda";
import { TestContext as xCallManagerContext, XcallManagerPDA } from "./xcall_manager/setup";
import { TestContext as BalancedDollarContext, BalancedDollarPDA } from "./balanced_dollar/setup";


import { AssetManager } from "../target/types/asset_manager";
import { XcallManager } from "../target/types/xcall_manager";
import { Xcall } from "../types/xcall";
import { CentralizedConnection } from "../types/centralized_connection";
const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);
const connection = provider.connection; //new Connection("https://solana-rpc.venture23.xyz", "confirmed");
let wallet = provider.wallet as anchor.Wallet;
let txnHelpers = new TransactionHelper(connection, wallet.payer);

import connectionIdlJson from "../target/idl/centralized_connection.json";
const connectionProgram: anchor.Program<CentralizedConnection> =
  new anchor.Program(connectionIdlJson as anchor.Idl, provider) as unknown as anchor.Program<CentralizedConnection> ;
  import xcallIdlJson from "../target/idl/xcall.json";
const xcall_program: anchor.Program<Xcall> = new anchor.Program(xcallIdlJson as anchor.Idl, provider) as unknown as anchor.Program<Xcall> ;
import xcallManagerIdlJson from "../target/idl/xcall_manager.json";
const xcall_manager_program: anchor.Program<XcallManager> =
new anchor.Program(xcallManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<XcallManager> ;
  import assetManagerIdlJson from "../target/idl/asset_manager.json";
const asset_manager_program: anchor.Program<AssetManager> =
new anchor.Program(assetManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<AssetManager> ;
import balancedDollarIdlJson from "../target/idl/balanced_dollar.json";
const balanced_dollar_program: anchor.Program<BalancedDollar> =
new anchor.Program(balancedDollarIdlJson as anchor.Idl, provider) as unknown as anchor.Program<BalancedDollar> ;
import * as rlp from 'rlp';

import { TestContext as XcallContext } from "./xcall/setup";
import { TestContext as ConnectionContext } from "./centralized_connection/setup";
import { BalancedDollar } from "../target/types/balanced_dollar";
import { assert } from "console";
import { Account, createMint, getOrCreateAssociatedTokenAccount, mintTo, TOKEN_PROGRAM_ID } from "@solana/spl-token";
import { BN } from "bn.js";
import { SYSTEM_PROGRAM_ID } from "@coral-xyz/anchor/dist/cjs/native/system";



let connectionCtx = new ConnectionContext(
    connection,
    txnHelpers,
    wallet.payer
);
let xcallCtx = new XcallContext(connection, txnHelpers, wallet.payer);
let xcallManagerCtx =  new xCallManagerContext(
    connection, txnHelpers, wallet.payer
);
let assetManagerContext =  new AssetManagerContext(
    connection, txnHelpers, wallet.payer
);
let balancedDollarContext =  new BalancedDollarContext(
    connection, txnHelpers, wallet.payer
);

let networkId = "solana";
let icon_governance = "0x2.icon/cxdb3d3e2717d4896b336874015a4b23871e62fb6b";
let icon_asset_manager = "0x2.icon/cxe9d69372f6233673a6ebe07862e12af4c2dca632";
let icon_balanced_dollar = "0x2.icon/cx87f7f8ceaa054d46ba7343a2ecd21208e12913c6";
let icon_connection_contract = "cx07300971594d7160a9ec62e4ec68d8fa10b9d9dc";
let sources = [connectionProgram.programId.toString()];
let destinations = [icon_connection_contract];
const walletPath = "/Users/sagarsapkota/docs/ibriz/solanawallet/devnet_wallet.json"; // Update this to the actual path
const secretKey = JSON.parse(fs.readFileSync(walletPath, 'utf8'));
const nativeDepositor = Keypair.fromSecretKey(new Uint8Array(secretKey));

let mint: PublicKey;
let vaultTokenAccount: Account;
async function deposit_native() {
  let { pda } = XcallPDA.config();
  let xcall_config = await xcall_program.account.config.fetch(pda);
  //let nativeDepositor = Keypair.generate();
  await txnHelpers.airdrop(nativeDepositor.publicKey, 5000000000);
  // Check the balance to ensure it has been funded
  const initialBalance = await provider.connection.getBalance(nativeDepositor.publicKey);
  console.log("initial native token balance: ", initialBalance);
  assert(initialBalance > 0 == true);
  
  await  sleep(3);
  let bytes = Buffer.alloc(0);
  let depositTokenIx = 
  await asset_manager_program.methods
    .depositNative(new BN(1000000000), "0x2.icon/hxd911279d689705ecdcffc8b884915f89968232569", bytes)
    .accountsStrict({
      from: null,
      fromAuthority: nativeDepositor.publicKey,
      vaultTokenAccount: null,
      vaultNativeAccount: AssetManagerPDA.vault_native().pda,
      state: AssetManagerPDA.state().pda,
      xcallManagerState: AssetManagerPDA.xcall_manager_state().pda,
      xcallConfig: XcallPDA.config().pda,
      xcall: xcall_program.programId,
      xcallManager: xcall_manager_program.programId,
      tokenProgram: null,
      systemProgram: SYSTEM_PROGRAM_ID,
    }).remainingAccounts([
      {
        pubkey: XcallPDA.config().pda,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: XcallPDA.rollback(xcall_config.sequenceNo.toNumber()+1).pda,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: new PublicKey("Sysvar1nstructions1111111111111111111111111"),
        isSigner: false,
        isWritable: false,
      },
      {
        pubkey: xcall_config.feeHandler,
        isSigner: false,
        isWritable: true,
      },
      //connection params
      {
        pubkey: connectionProgram.programId,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: ConnectionPDA.config().pda,
        isSigner: false,
        isWritable: true,
      },
      {
        pubkey: ConnectionPDA.fee("0x2.icon").pda,
        isSigner: false,
        isWritable: true,
      },
    ]).instruction();
    const modifyComputeUnits = ComputeBudgetProgram.setComputeUnitLimit({ 
      units: 1000000 
    });
    
    const addPriorityFee = ComputeBudgetProgram.setComputeUnitPrice({ 
      microLamports: 0
    });
  let tx = await txnHelpers.buildV0Txn([modifyComputeUnits, addPriorityFee, depositTokenIx], [nativeDepositor]);
  let txHash = await connection.sendTransaction(tx);
  txnHelpers.logParsedTx(txHash);
  console.log("native deposited");
  sleep(3);
  const updatedBalance = await provider.connection.getBalance(nativeDepositor.publicKey);
  console.log("updated native token balance: ", updatedBalance);

}

async function main() {
    await deposit_native();
}

main().catch(err => console.error(err));