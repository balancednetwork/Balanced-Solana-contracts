//imports
import * as anchor from "@coral-xyz/anchor";
import { Keypair, PublicKey } from "@solana/web3.js";

import { TransactionHelper, sleep } from "./utils";
import { TestContext as AssetManagerContext, AssetManagerPDA } from "./asset_manager/setup";
import { XcallPDA, ConnectionPDA } from "./utils/xcall_pda";
import { TestContext as xCallManagerContext, XcallManagerPDA } from "./xcall_manager/setup";
import { TestContext as BalancedDollarContext, BalancedDollarPDA } from "./balanced_dollar/setup";


import { AssetManager } from "../target/types/asset_manager";
import { XcallManager } from "../target/types/xcall_manager";
import { BalancedDollar } from "../target/types/balanced_dollar";
import { Xcall } from "../types/xcall";
import { CentralizedConnection } from "../types/centralized_connection";

const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);
const connection = provider.connection; //new Connection("https://solana-rpc.venture23.xyz", "confirmed");
let wallet = provider.wallet as anchor.Wallet;
let txnHelpers = new TransactionHelper(connection, wallet.payer);

import connectionIdlJson from "../target/idl/centralized_connection.json";
const connectionProgram: anchor.Program<CentralizedConnection> =
  new anchor.Program(connectionIdlJson as anchor.Idl, provider) as unknown as anchor.Program<CentralizedConnection> ;
  import xcallIdlJson from "../target/idl/xcall.json";
const xcall_program: anchor.Program<Xcall> = new anchor.Program(xcallIdlJson as anchor.Idl, provider) as unknown as anchor.Program<Xcall> ;
import xcallManagerIdlJson from "../target/idl/xcall_manager.json";
const xcall_manager_program: anchor.Program<XcallManager> =
new anchor.Program(xcallManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<XcallManager> ;
  import assetManagerIdlJson from "../target/idl/asset_manager.json";
const asset_manager_program: anchor.Program<AssetManager> =
new anchor.Program(assetManagerIdlJson as anchor.Idl, provider) as unknown as anchor.Program<AssetManager> ;
import balancedDollarIdlJson from "../target/idl/balanced_dollar.json";
const balanced_dollar_program: anchor.Program<BalancedDollar> =
new anchor.Program(balancedDollarIdlJson as anchor.Idl, provider) as unknown as anchor.Program<BalancedDollar> ;
import * as rlp from 'rlp';

import { TestContext as XcallContext } from "./xcall/setup";
import { TestContext as ConnectionContext } from "./centralized_connection/setup";

import { SYSTEM_PROGRAM_ID } from "@coral-xyz/anchor/dist/cjs/native/system";
import assert from "assert";
import { Account, createMint, getOrCreateAssociatedTokenAccount, mintTo, TOKEN_PROGRAM_ID } from "@solana/spl-token";
import { CSMessage, CSMessageRequest, CSMessageType, MessageType } from "./types";


let connectionCtx = new ConnectionContext(
    connection,
    txnHelpers,
    wallet.payer
);
let xcallCtx = new XcallContext(connection, txnHelpers, wallet.payer);
let xcallManagerCtx =  new xCallManagerContext(
    connection, txnHelpers, wallet.payer
);
let assetManagerContext =  new AssetManagerContext(
    connection, txnHelpers, wallet.payer
);
let balancedDollarContext =  new BalancedDollarContext(
    connection, txnHelpers, wallet.payer
);

// async function getExecuteCallAccounts(data: Uint8Array) {
//     let xcallConfig = await xcallCtx.getConfig();
//     let reqId = xcallConfig.lastReqId.toNumber();


//     const res = await xcall_program.methods
//       .queryExecuteCallAccounts(new anchor.BN(reqId), Buffer.from(data), 1, 30)
//       .accountsStrict({
//         config: XcallPDA.config().pda,
//         proxyRequest: XcallPDA.proxyRequest(reqId).pda,
//       })
//       .remainingAccounts([
//         {
//           pubkey: ConnectionPDA.config().pda,
//           isWritable: true,
//           isSigner: false,
//         },
//         {
//           pubkey: BalancedDollarPDA.state().pda,
//           isWritable: true,
//           isSigner: false,
//         },
//         {
//           pubkey: connectionProgram.programId,
//           isWritable: true,
//           isSigner: false,
//         },
//         {
//           pubkey: balanced_dollar_program.programId,
//           isWritable: true,
//           isSigner: false,
//         },
//       ])
//       .view({ commitment: "confirmed" });

//     return res.accounts;
//   }

async function get_acounts_direct() {
    let to = Keypair.generate();
    const data = ["WithdrawTo", wallet.publicKey.toString(), wallet.publicKey.toString(), 1000000000];
    const rlpEncodedData = rlp.encode(data);
    
    let accounts = await asset_manager_program.methods
      .queryHandleCallMessageAccounts("", Buffer.from(rlpEncodedData), [])
      .accounts({
        state: AssetManagerPDA.state().pda,
      }).view();
      
      console.log("accounts: {}", accounts);
}

async function get_acounts_direct_bnusd() {
    let to = Keypair.generate();
    let bytes = Buffer.alloc(0);
    const data = ["xCrossTransfer", wallet.publicKey.toString(), wallet.publicKey.toString(), 20000000000,  bytes];
    const rlpEncodedData = rlp.encode(data);
    console.log("bnusd pda: ", BalancedDollarPDA.state().pda);
    console.log("connection: ", provider.connection);
    let accounts = await balanced_dollar_program.methods
      .queryHandleCallMessageAccounts("", Buffer.from(rlpEncodedData), [])
      .accounts({
        state: BalancedDollarPDA.state().pda,
      }).view();
      
      console.log("accounts: {}", accounts);
}

async function get_acounts_direct_native_token() {
  let to = Keypair.generate();
  console.log("to address: ", to.publicKey);
  const data = ["WithdrawNativeTo", "11111111111111111111111111111111", to.publicKey.toString(), 1000000000];
  const rlpEncodedData = rlp.encode(data);
  console.log("bnusd pda: ", AssetManagerPDA.state().pda);
  console.log("connection: ", provider.connection);
  let accounts = await asset_manager_program.methods
    .queryHandleCallMessageAccounts("", Buffer.from(rlpEncodedData), [])
    .accounts({
      state: AssetManagerPDA.state().pda,
    }).view();
    
    console.log("accounts: {}", accounts);
}

async function get_accounts() {
    
    // let data = "f8818e7843726f73735472616e73666572b33078322e69636f6e2f687864393131323739643638393730356563646366666338623838343931356638393936383233323536b3736f6c616e612f31345943467143463972513142456d506567775a4b6a4b7773476f50356431415a6d4a6d55585a5454454135881bc16d674ec8000080";
    // // let accounts = await xcall_program.methods.queryExecuteCallAccounts(1, hexToBytes(data) as Uint8Array , 1, 30)
    // // .accountsStrict({
    // //     config: XcallPDA.config().pda,
    // //     proxyRequest: ""
    // // }).view();
    // // console.log("accounts: ", accounts);

    const data = ["WithdrawTo", wallet.publicKey.toString(), wallet.publicKey.toString(), 1000000000];
    const rlpEncodedData = rlp.encode(data);

    // let request = new CSMessageRequest(
    //     "icon/abc",
    //     "icon",
    //     1,
    //     MessageType.CallMessage,
    //     new Uint8Array([0, 1, 2, 3]),
    //     [
    //       wallet.publicKey.toString(),
    //       wallet.publicKey.toString(),
    //       SYSTEM_PROGRAM_ID.toString(),
    //     ]
    //   );
  
    //   let cs_message = new CSMessage(
    //     CSMessageType.CSMessageRequest,
    //     request.encode()
    //   ).encode();

    const res = await xcall_program.methods
      .queryExecuteCallAccounts(new anchor.BN(1), Buffer.from(rlpEncodedData), 1, 30)
      .accountsStrict({
        config: XcallPDA.config().pda,
        proxyRequest: XcallPDA.proxyRequest(1).pda,
      })
      .remainingAccounts([
        {
          pubkey: ConnectionPDA.config().pda,
          isWritable: true,
          isSigner: false,
        },
        {
          pubkey: BalancedDollarPDA.state().pda,
          isWritable: true,
          isSigner: false,
        },
        {
          pubkey: connectionProgram.programId,
          isWritable: true,
          isSigner: false,
        },
        {
          pubkey: balanced_dollar_program.programId,
          isWritable: true,
          isSigner: false,
        },
      ])
      .view({ commitment: "confirmed" });

    return res.accounts;
}

// async getExecuteCallAccounts(reqId: number, data: Uint8Array) {
//     const res = await xcallProgram.methods
//       .queryExecuteCallAccounts(new anchor.BN(reqId), Buffer.from(data), 1, 30)
//       .accountsStrict({
//         config: XcallPDA.config().pda,
//         proxyRequest: XcallPDA.proxyRequest(reqId).pda,
//       })
//       .remainingAccounts([
//         {
//           pubkey: ConnectionPDA.config().pda,
//           isWritable: true,
//           isSigner: false,
//         },
//         {
//           pubkey: DappPDA.config().pda,
//           isWritable: true,
//           isSigner: false,
//         },
//         {
//           pubkey: connectionProgram.programId,
//           isWritable: true,
//           isSigner: false,
//         },
//         {
//           pubkey: mockDappProgram.programId,
//           isWritable: true,
//           isSigner: false,
//         },
//       ])
//       .view({ commitment: "confirmed" });

//     return res.accounts;
//   }

function hexToBytes(hex: string) {
    if (hex.length % 2 !== 0) {
        throw new Error('Hex string must have an even length');
    }

    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < hex.length; i += 2) {
        bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
    }
    return bytes;
}

async function main() {
    //await get_accounts();
    //let accounts = get_acounts_direct();
    //get_acounts_direct_bnusd();
    get_acounts_direct_native_token();
    //console.log(accounts);
}

main().catch(err => console.error(err));


