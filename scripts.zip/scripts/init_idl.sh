anchor idl init --filepath target/idl/centralized_connection.json 4vfkXyxMxptmREF3RaFKUwnPRuqsXJJeUFzpCjPSSVMb --provider.cluster https://solana-rpc.venture23.xyz
anchor idl init --filepath target/idl/xcall.json 47QmEHEPSQqhpEjok5PmooeqdqBXRVpU11aRMhJGe6LW --provider.cluster https://solana-rpc.venture23.xyz 
anchor idl init --filepath target/idl/asset_manager.json 8tJx9uFHvK33etttKFi8XWHEKMo3q3K6UdSWLTTKnUvX --provider.cluster https://solana-rpc.venture23.xyz
anchor idl init --filepath target/idl/balanced_dollar.json 7pvzYSgsMmK81xtXFCD5VQVbCZurTFxPNQ2FZHUd5rTY --provider.cluster https://solana-rpc.venture23.xyz
anchor idl init --filepath target/idl/xcall_manager.json 7vfrBqZFbvfKCqVC3v7dEh8V6RV9afRu1ySuLLauCMTL --provider.cluster https://solana-rpc.venture23.xyz
